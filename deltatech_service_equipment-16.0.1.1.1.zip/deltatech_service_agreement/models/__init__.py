# ©  2008-2021 Deltatech
# See README.rst file on addons root folder for license details


from . import service_agreement
from . import service_consumption
from . import account_move
from . import account_journal
