# ©  2023 Deltatech
# See README.rst file on addons root folder for license details


from . import test_agreement
