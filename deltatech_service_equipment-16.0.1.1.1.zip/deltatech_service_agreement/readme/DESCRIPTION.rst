Features:
 - Ofera posibilitatea de a defini contracte de servicii.
    - in contract se pot specifica: moneda, data de facturare, recurenta
 - Periodic in baza acestor contracte se genereaza facturi
    - consumurile se servicii planificate se pot actualiza cu cele efective inainte de facturare
