# ©  2015-2022 Deltatech
# See README.rst file on addons root folder for license details


import logging
from datetime import datetime

from odoo import api, fields, models

_logger = logging.getLogger(__name__)

READING_TYPE_SELECTION = [("inc", "Increase"), ("dec", "Decrease"), ("cng", "Change"), ("src", "Meter")]


class ServiceMeter(models.Model):
    _name = "service.meter"
    _description = "Meter"
    _rec_name = "display_name"

    name = fields.Char(string="Name")
    display_name = fields.Char(compute="_compute_display_name")

    meter_categ_id = fields.Many2one("service.meter.category", string="Category", required=True)
    type = fields.Selection(string="Type", related="meter_categ_id.type", readonly=True)
    equipment_id = fields.Many2one(
        "service.equipment", string="Equipment", required=True, ondelete="cascade", index=True
    )
    meter_reading_ids = fields.One2many("service.meter.reading", "meter_id", string="Meter Reading")

    meter_ids = fields.Many2many(
        "service.meter",
        "service_meter_collector_meter",
        "meter_collector_id",
        "meter_id",
        string="Meter",
        domain=[("type", "=", "counter")],
    )

    start_value = fields.Float(string="Start Value", digits="Meter Value")
    last_meter_reading_id = fields.Many2one(
        "service.meter.reading",
        string="Last Meter Reading",
        compute="_compute_last_meter_reading",
        store=True,
    )
    last_reading_date = fields.Date(
        string="Last reading date",
        compute="_compute_last_meter_reading",
        store=True,
    )

    total_counter_value = fields.Float(
        string="Total Counter Value",
        digits="Meter Value",
        compute="_compute_last_meter_reading",
        store=True,
    )
    estimated_value = fields.Float(string="Estimated Value", digits="Meter Value", compute="_compute_estimated_value")

    uom_id = fields.Many2one("uom.uom", string="Unit of Measure", required=True, index=True)

    value_a = fields.Float()
    value_b = fields.Float()
    company_id = fields.Many2one("res.company", required=True, default=lambda self: self.env.company)

    _sql_constraints = [
        (
            "equipment_uom_uniq",
            "unique(equipment_id,uom_id)",
            "Two meter for one equipment with the same unit of measure? Impossible!",
        )
    ]

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if ("name" not in vals) or (vals.get("name") in ("/", False)):
                sequence = self.env.ref("deltatech_service_equipment_base.sequence_meter")
                if sequence:
                    vals["name"] = sequence.next_by_id()
        return super().create(vals_list)

    # rutina pentru actualizare date curente
    def update_name(self):
        sequence = self.env.ref("deltatech_service_equipment_base.sequence_meter")
        if sequence:
            meters = self.env["service.meter"].search([("name", "=", False)])
            for meter in meters:
                meter.name = sequence.next_by_id()

    # rutina pentru actualizare date curente
    def update_categ(self):
        meters = self.env["service.meter"].search([("meter_categ_id", "=", False)])
        for meter in meters:
            categ = self.env["service.meter.category"].search([("uom_id", "=", meter.uom_id.id)])
            if categ:
                meter.meter_categ_id = categ.id

    @api.depends("name", "uom_id")
    def _compute_display_name(self):
        for meter in self:
            if meter.name:
                meter.display_name = "{} [{}]".format(meter.name, meter.uom_id.name)
            else:
                meter.display_name = meter.uom_id.name

    @api.onchange("meter_categ_id")
    def onchange_meter_categ_id(self):
        if self.meter_categ_id:
            self.uom_id = self.meter_categ_id.uom_id

    @api.depends("meter_reading_ids", "meter_reading_ids.counter_value", "meter_ids")
    def _compute_last_meter_reading(self):
        for meter in self:
            total_counter_value = 0
            last_meter_reading_id = False
            if meter.type == "counter":
                if meter.meter_reading_ids:
                    last_meter_reading_id = meter.meter_reading_ids[0]
                    meter.last_reading_date = meter.meter_reading_ids[0].date
                    total_counter_value = last_meter_reading_id.counter_value
            else:
                for child_meter in meter.meter_ids:
                    total_counter_value += child_meter.meter_reading_ids[0].counter_value

            meter.last_meter_reading_id = last_meter_reading_id
            meter.total_counter_value = total_counter_value

    def _compute_estimated_value(self):
        for meter in self:
            date = self.env.context.get("date", fields.Date.today())
            meter.estimated_value = meter.get_forcast(date)

    def calc_forecast_coef(self):
        def linreg(X, Y):
            """
            return a,b in solution to y = ax + b such that root mean square distance between
            trend line and original points is minimized
            """
            N = len(X)
            Sx = Sy = Sxx = Syy = Sxy = 0.0
            for x, y in zip(X, Y):
                Sx = Sx + x
                Sy = Sy + y
                Sxx = Sxx + x * x
                Syy = Syy + y * y
                Sxy = Sxy + x * y
            det = Sxx * N - Sx * Sx
            if det:
                a, b = (Sxy * N - Sy * Sx) / det, (Sxx * Sy - Sx * Sxy) / det
            else:
                a = b = 0.0
            return a, b

        for meter in self:
            x = []
            y = []
            for reading in meter.meter_reading_ids:
                if not reading.estimated:
                    x += [fields.Date.from_string(reading.date).toordinal()]
                    y += [reading.counter_value]

            a, b = linreg(x, y)
            meter.write({"value_a": a, "value_b": b})
            # _logger.info("Value A: %s, Value B: %s" % (str(a), str(b) ))

    @api.model
    def get_forcast(self, date):
        """Calculeaza valoarea estimata in functie de data"""
        self.ensure_one()
        x = fields.Date.from_string(date).toordinal()
        res = self.value_a * x + self.value_b
        if not res:
            res = self.total_counter_value
        return res

    @api.model
    def get_forcast_date(self, value):
        """Calculeaza data estimata in functie de valoare"""
        self.ensure_one()
        if self.value_a:
            x = (value - self.value_b) / self.value_a
            date = datetime.fromordinal(int(x))
            date = fields.Date.to_string(date)
        else:
            date = False
        return date

    def get_counter_value(self, begin_date, end_date):
        value = 0
        if self.type == "counter":
            domain = [("date", ">=", begin_date), ("date", "<", end_date), ("meter_id", "=", self.id)]
            res = self.env["service.meter.reading"].read_group(
                domain, fields=["difference", "meter_id"], groupby=["meter_id"]
            )
            if res:
                value = res[0].get("difference", 0)
        else:
            for meter in self.meter_ids:
                value += meter.get_counter_value(begin_date, end_date)
        return value

    def recheck_value(self):
        for meter in self:
            readings = meter.meter_reading_ids.sorted(key=lambda r: r.date)
            previous_counter_value = meter.start_value
            for reading in readings:
                # reading.previous_counter_value = previous_counter_value
                # difference =
                # reading._store_set_values
                reading.write(
                    {
                        "previous_counter_value": previous_counter_value,
                        "difference": reading.counter_value - previous_counter_value,
                    }
                )
                previous_counter_value = reading.counter_value


class ServiceMeterReading(models.Model):
    _name = "service.meter.reading"
    _description = "Meter Reading"
    _order = "meter_id, date desc, id desc"
    _rec_name = "counter_value"

    meter_id = fields.Many2one(
        "service.meter", string="Meter", required=True, ondelete="cascade", domain=[("type", "=", "counter")]
    )

    equipment_id = fields.Many2one("service.equipment", string="Equipment", required=True, ondelete="restrict")
    partner_id = fields.Many2one(
        "res.partner",
        string="Customer",
        related="equipment_id.partner_id",
        store=True,
        readonly=True,
        help="The owner of the equipment",
    )

    date = fields.Date(string="Date", index=True, required=True, default=fields.Date.context_today)
    previous_counter_value = fields.Float(
        string="Previous Counter Value",
        readonly=True,
        digits="Meter Value",
        compute="_compute_previous_counter_value",
        store=True,
    )
    counter_value = fields.Float(string="Counter Value", digits="Meter Value", group_operator="max")
    estimated = fields.Boolean(string="Estimated")
    difference = fields.Float(
        string="Difference", readonly=True, digits="Meter Value", compute="_compute_difference", store=True
    )

    read_by = fields.Many2one("res.partner", string="Read by", domain=[("is_company", "=", False)])
    note = fields.Text(string="Notes")
    imported = fields.Boolean(string="Imported")
    company_id = fields.Many2one("res.company", required=True, default=lambda self: self.env.company)

    # todo: de adaugat status: ciorna, valid, neplauzibil, facturat ?

    @api.depends("date", "meter_id", "equipment_id")
    def _compute_previous_counter_value(self):
        for reading in self:
            reading.previous_counter_value = reading.meter_id.start_value
            if reading.date and reading.meter_id:
                previous = self.env["service.meter.reading"].search(
                    [("meter_id", "=", reading.meter_id.id), ("date", "<", reading.date)],
                    limit=1,
                    order="date desc, id desc",
                )
                if previous:
                    reading.previous_counter_value = previous.counter_value
                    reading.difference = reading.counter_value - reading.previous_counter_value
                    # self.invalidate_recordset() # asta e solutia ?

    @api.depends("counter_value", "previous_counter_value")
    def _compute_difference(self):
        for reading in self:
            reading.difference = reading.counter_value - reading.previous_counter_value
            next_reading = self.env["service.meter.reading"].search(
                [("meter_id", "=", reading.meter_id.id), ("date", ">", reading.date)], limit=1, order="date, id"
            )
            if next_reading and next_reading.previous_counter_value != reading.counter_value:
                next_reading.write(
                    {
                        "previous_counter_value": reading.counter_value,
                        "difference": (next_reading.counter_value - reading.counter_value),
                    }
                )

    @api.onchange("meter_id")
    def onchange_meter_id(self):
        if self.meter_id:
            self.equipment_id = self.meter_id.equipment_id

    def write(self, vals):
        res = super().write(vals)
        if vals.get("date", False):
            for reading in self:
                reading.meter_id.recheck_value()
                reading.meter_id.calc_forecast_coef()
        return res
