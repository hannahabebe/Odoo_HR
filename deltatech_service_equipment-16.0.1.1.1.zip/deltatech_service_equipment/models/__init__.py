# ©  2015-2018 Deltatech
# See README.rst file on addons root folder for license details


from . import service_config
from . import service_equipment
from . import service_meter
from . import service_agreement
from . import res_config_settings
from . import service_history
from . import stock_location
from . import product

from . import account_move
from . import stock_production_lot
