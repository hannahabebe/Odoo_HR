Features:
    - equipment management
    - counters management
    - reading counters management
    - biling based on readings
    - reading estimate calculation
    - automatic introduction at end of the period at estimated values
